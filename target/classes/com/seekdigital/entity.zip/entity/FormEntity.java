package com.seekdigital.entity;

public class FormEntity {
	private Mstregistration mstregistration;
	private Mstbank mstbank;
	public Mstregistration getMstregistration() {
		return mstregistration;
	}
	public void setMstregistration(Mstregistration mstregistration) {
		this.mstregistration = mstregistration;
	}
	public Mstbank getMstbank() {
		return mstbank;
	}
	public void setMstbank(Mstbank mstbank) {
		this.mstbank = mstbank;
	}
	

	

}
